

=== Selcom Payment Plugin ===
Contributors: Selcom Tech Team
Tags: selcom, payments, integration
Requires at least: 4.0
Tested up to: 5.7
Requires PHP: 5.6
Stable tag: 1.0.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
This plugin helps developers integrate Selcom Payments to their e-commerce platforms.

== Installation ==
1. Upload "wp-selcom-payment.php" to the "/wp-content/plugins/" directory.
2. Activate the plugin through the "Plugins" menu in WordPress.
3. Go to WooCommerce Payments tab
4. Fill out your Selcom provided API_KEY, API_Secret and your VENDOR TILL.
5. Set Selcom Payment as one of the payment methods.
6. We're good to go!

== Changelog ==

= 1.0.2 =
* Upgraded Selcom Payment APIs.


= 1.0.1 =
* Modified selection of order status on successful payments.


= 0.1 =
* Initial release.

== Upgrade Notice ==
= 0.2 =
Upgrade notices describe the reason a user should upgrade

= 0.1 =
This version fixes a security related bug. Upgrade immediately.
